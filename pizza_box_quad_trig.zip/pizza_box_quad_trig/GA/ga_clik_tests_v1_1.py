from __future__ import division
from sympy import *
from sympy.printing.c import C99CodePrinter
import sympy as sym
import numpy as np
import os
import math
import sys
import random as rnd

# The GA code 
sys.path.append('../GATO/')
import ga_toolkit_v2 as ga
import ga_clik_inflation_v1 as gac

# This calculates the chi^2 using the Planck likelihood (clik)
def chi2_CMB(kid,gram):
    phi=symbols("phi")
    VGA=ga.make_function(phi,kid,gram,GA_prior)
    dVGA=diff(VGA,phi)
    ddVGA=diff(dVGA,phi)
    printer = C99CodePrinter()
    VGAs=str(printer.doprint(VGA))
    dVGAs=str(printer.doprint(dVGA))
    ddVGAs=str(printer.doprint(ddVGA))
    return gac.chi2_CMB_potential(VGAs,dVGAs,ddVGAs)

def V_staro(phi,V0,phi0):
    gamma_S = math.sqrt(2./3.)*math.sqrt(8.*math.pi)
    return V0*pow(1.-sym.exp(gamma_S*(phi-phi0)),2.)

# Here you can also specify any physical priors.
# For example, you might need a scaling GA~x for x<<1, then you can say
# GA = x*(1+GA0) etc.

V0_S = 1.6948194298814304e-13
phi0_S = 1.0682906559037841

def GA_prior(x, GAx):
    #return V_staro(x,V0_S,phi0_S)*(1.+sym.sin(1.e-2*GAx))
	return V0_S*(1-0.104596*x-0.211338*x*x)*(1.+0.4*GAx)

#######################################
#######################################
#
# Here starts the main part of the code
#
#######################################
#######################################

# Some settings

# Here we define the grammar
# grammar = ['poly', 'polyxtox','cpl','trig1' (=cos)]
grammar = ['trig1']

# Here are the input params
input_params={
'Nchains' : 1,
'Ngens' : 700,
'Npops' : 100,
'Nseed' : rnd.randrange(1,100000),
'ranges': [[-1,1], [0,len(grammar)], [0, 2], [0, 10]], 
'length': 4, 
'depth' : 4, 
'selectionrate' : 0.3, 
'toursize' : 4, 
'crossoverrate' : 0.75, 
'mutationrate' : 0.3,
'verbose' :  True,
'save_chains' :  [True, 'chain_trig_2'],
'resume_chains' :  [False, './chains/chain_seed_xxxx.pic'],
'grammar' : grammar,
'GA_prior' : 'f(x) = '+str(GA_prior(symbols("phi"), symbols("GA")))
}

# Allocate some variables where we store the results
# bfps is the best fit per step // useful for plotting ;-)
run = [0] * input_params['Nchains']
bfps = [0] * input_params['Nchains']
seeds = [0] * input_params['Nchains']

for iseed in range(input_params['Nchains']):
	#seeds[iseed] = 100*(iseed+1)
	#input_params['Nseed'] = seeds[iseed]
	run[iseed] = ga.evolution(chi2_CMB, input_params, grammar)
	bfps[iseed] = [row[0] for row in run[iseed]]

print('The end!')

#print(bfps)
print('')
print('The best-fits from the runs are:')
best_fits=[row[-1] for row in bfps]
print(best_fits)
val, idx = min((val, idx) for (idx, val) in enumerate(best_fits))
print('')
print('The overall best-fit from the runs [chi^2, # of run]:')
print([val,idx])

print('')
print('With seed =',seeds[idx])

print('')
print('The best-fit symbolic expression is:')

# This uses sympy to write down a symbolic expression.
xs=symbols("phi")
expr=ga.make_function(xs,run[idx][-1][1],grammar,GA_prior)
print('')
print('V(phi) =',expr)

print('')
print("with a chi^2 = %.12f" % val)

print('')
print('best-fit linear pt: 2776.601028443289')
print('best-fit quadratic: 2773.577261642307')
print('best-fit starob pt: 2773.603416302499')
print('best-fit P(k) anal: 2773.647233207831')

exit()