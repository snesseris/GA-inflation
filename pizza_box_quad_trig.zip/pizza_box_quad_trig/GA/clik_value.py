from __future__ import division
#from sympy import *
from sympy.printing.c import C99CodePrinter
import sympy as sym
import numpy as np
import math

import sys
sys.path.append('../GATO/')

import ga_clik_inflation_v1 as gac


# Here define a potential in terms of phi in python notation
phi=sym.symbols("phi")
printer = C99CodePrinter()

# Starobinski type potential
V0_S = 1.6948194298814304e-13
phi0_S = 1.0682906559037841

gamma_S = math.sqrt(2./3.)*math.sqrt(8.*math.pi)
Vphi= V0_S*pow(1.-sym.exp(gamma_S*(phi-phi0_S)),2.)

# The derivatives
dVGA=sym.diff(Vphi,phi)
ddVGA=sym.diff(dVGA,phi)

# Convert to strings
VGAs=str(printer.doprint(Vphi))
dVGAs=str(printer.doprint(dVGA))
ddVGAs=str(printer.doprint(ddVGA))

# Calculate chi^2
print("")
print('chi^2 from potential...')
gac.chi2_CMB_potential(VGAs,dVGAs,ddVGAs)

print("")
print("------------------------------")
print("")
print('chi^2 from P(k)~As k^(ns-1)...')
gac.chi2_CMB_analytic()

print("")
print("------------------------------")
print("")
chi2exp = [23.25147965785152, 396.049933292438, 2344.9308271318932, 8.867964585046845]
print("Best-fit Planck chi^2:")
print(chi2exp)
print(sum(chi2exp))

exit()