#!/bin/sh
#SBATCH -J SPARTA
#SBATCH --partition=medium
#SBATCH --get-user-env
#SBATCH -o ./job.%j.out
#SBATCH -e ./job.%j.err
#SBATCH -n 1
#SBATCH -c 8
#SBATCH -t 2-23:59:00
#SBATCH --mem=2GB
#SBATCH --mail-type=begin
#SBATCH --mail-type=end
#SBATCH --mail-user=savvas.nesseris@csic.es

export OMP_NUM_THREADS=8

cd ../class_public-3.1.3
make class
cd ../GA

srun python3.7 ./ga_clik_tests_v1_6.py