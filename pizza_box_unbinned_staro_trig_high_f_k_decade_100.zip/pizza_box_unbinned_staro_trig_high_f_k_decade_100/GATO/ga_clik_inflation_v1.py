import clik
import sys
import numpy as np
import os

# Here set the path to clik and CLASS
PLANCK_PATH = '/mnt/netapp2/Home_FT2/home/csic/ift/sne/planck/'
PLANCK_PATH_LUSTRE ='/mnt/lustre/scratch/nlsas/home/csic/ift/sne'
sys.path.append(PLANCK_PATH + 'code/plc_3.0/plc-3.1/lib/python/site-packages')

CLASS_PATH = '../class_public-3.1.3'

def call_clik(file):
	
	# Set the position of the spectra in the Cl file
	TTpos=1
	EEpos=2
	BBpos=3
	TEpos=4
	phipos=5
	
	if os.path.isfile(file):
		# Read the Cls from the txt file.
		cls = np.loadtxt(file)
		
		#print("Now do the low-l TT and TE ...")
		lmax= CMBlkl_low_TT.get_lmax()[0]
		lc = np.array(range(2,lmax+1))
		factor = 1/(lc*(lc+1)/(2*np.pi))

		TT = cls[0:(lmax-1),TTpos]*factor
		EE = cls[0:(lmax-1),EEpos]*factor

		inputTT=np.concatenate((np.array([0,0]),np.asarray(TT),np.array([A_planck])),axis=None)
		inputEE=np.concatenate((np.array([0,0]),np.asarray(EE),np.array([A_planck])),axis=None)
		try:
			chi2_low_TT = -2.0*CMBlkl_low_TT(inputTT)[0]
		except: 
			chi2_low_TT = 1.e+30
		try: 
			chi2_low_EE = -2.0*CMBlkl_low_EE(inputEE)[0] 
		except:
			chi2_low_EE = 1.e+30
		
		#print("Now do the high-l TT_TE_EE ...")
		lmax= CMBlkl_hi_TTTEEE.get_lmax()[0]
		lc = np.array(range(2,lmax+1))
		factor = 1/(lc*(lc+1)/(2*np.pi))

		TT = cls[0:(lmax-1),TTpos]*factor
		EE = cls[0:(lmax-1),EEpos]*factor
		#BB = cls[0:(lmax-1),BBpos]*factor
		TE = cls[0:(lmax-1),TEpos]*factor

		inputTTTEEE = np.concatenate((np.array([0,0]),np.asarray(TT),np.array([0,0]),np.asarray(EE),np.array([0,0]),np.asarray(TE),np.array(nuisance)),axis=None)
		try: 
			chi2_hi_TTTEEE = -2.0*CMBlkl_hi_TTTEEE(inputTTTEEE)[0]
		except:
			chi2_hi_TTTEEE = 1.e+30

		#print("Now do the lensing...")
		lmax= CMBlkl_lensing.get_lmax()[0]
		lc = np.array(range(2,lmax+1))
		factor = 1/(lc*(lc+1)/(2*np.pi))
		factorphi = 2*np.pi/(lc*(lc+1))**2

		TT = cls[0:(lmax-1),TTpos]*factor
		EE = cls[0:(lmax-1),EEpos]*factor
		#BB = cls[0:(lmax-1),BBpos]*factor
		TE = cls[0:(lmax-1),TEpos]*factor
		phiphi = cls[0:(lmax-1),phipos]*factorphi

		inputlensing=np.concatenate((np.array([0,0]),np.asarray(phiphi),np.array([0,0]),np.asarray(TT),np.array([0,0]),np.asarray(EE),np.array([0,0]),np.asarray(TE),np.array([A_planck])),axis=None)

		try: 
			chi2_lensing = -2.0*CMBlkl_lensing(inputlensing)[0]
		except:
			chi2_lensing = 1.e+30

		# This is the total chi^2
		chi2_vec = [chi2_low_TT, chi2_low_EE, chi2_hi_TTTEEE, chi2_lensing]
		chi2 = chi2_low_TT+chi2_low_EE+chi2_hi_TTTEEE+chi2_lensing
		print('              low-TT, low-EE, hi-TTTEEE, lensing')
		print('chi^2 vector: ', chi2_vec)
		print('total chi^2 : ', chi2)
	else:
		# If CLASS crashed return a crazy large value
		print("CLASS probably crashed!!! :'(")
		chi2 = 2.e+30
	return chi2

def chi2_CMB_potential(VGA,dVGA,ddVGA):

	V='    *V   = '+VGA+';\n'
	dV='    *dV  = '+dVGA+';\n'
	ddV='    *ddV = '+ddVGA+';\n'

	with open(CLASS_PATH+'/source/primordial.c', 'r') as f_in:
		data=f_in.readlines()

	data[985]=V
	data[986]=dV
	data[987]=ddV

	with open(CLASS_PATH+'/source/primordial.c', 'w') as f_out:
		f_out.writelines(data)

	os.system("cd "+CLASS_PATH+"; make class > /dev/null")
	os.system("cd "+CLASS_PATH+"; rm ./output/GA_inflationV_* > /dev/null")	
	
	print("")
	print("------------------------------")
	print("")
	print(V)

	os.system("cd "+CLASS_PATH+";./class ./GA_inflationV.ini | grep -E 'A_s=|r='")
	
	# Here we set the filename for the Cls from CLASS and the positions for the spectra
	files=[CLASS_PATH+'/output/GA_inflationV_cl_lensed.dat']

	# Here we call clik
	return call_clik(files[0])

def chi2_CMB_analytic():

	os.system("cd "+CLASS_PATH+"; rm ./output/GA_analytic_* > /dev/null")	
	
	print("")
	print("------------------------------")
	print("")

	os.system("cd "+CLASS_PATH+";./class ./GA_analytic.ini | grep -E 'A_s=|r='")
	
	# Here we set the filename for the Cls from CLASS and the positions for the spectra
	files=[CLASS_PATH+'/output/GA_analytic_cl_lensed.dat']
	
	# Here we call clik
	return call_clik(files[0])


# Load/initialize the likelihoods. 

# The low-l TT likelihood:
CMBlkl_low_TT = clik.clik(PLANCK_PATH + '/baseline/plc_3.0/low_l/commander/commander_dx12_v3_2_29.clik')
# print("CMBlkl_low_TT")
# print(CMBlkl_low_TT.get_extra_parameter_names())
# print(CMBlkl_low_TT.get_lmax())
# print("---------------------")
# print("")
# print("")

# The low-l EE likelihood:
CMBlkl_low_EE = clik.clik(PLANCK_PATH +'/baseline/plc_3.0/low_l/simall/simall_100x143_offlike5_EE_Aplanck_B.clik')
# print("CMBlkl_low_EE")
# print(CMBlkl_low_EE.get_extra_parameter_names())
# print(CMBlkl_low_EE.get_lmax())
# print("---------------------")
# print("")
# print("")

# The unbinned high-l TT-TE-EE likelihood:
#CMBlkl_hi_TTTEEE = clik.clik(PLANCK_PATH + '/baseline/plc_3.0/hi_l/plik/plik_rd12_HM_v22b_TTTEEE.clik')
CMBlkl_hi_TTTEEE = clik.clik(PLANCK_PATH_LUSTRE + '/plik_rd12_HM_v22b_TTTEEE_bin1.clik')
# print("CMBlkl_hi_TTTEEE")
# print(CMBlkl_hi_TTTEEE.get_extra_parameter_names())
# print(CMBlkl_hi_TTTEEE.get_lmax())
# print("---------------------")
# print("")
# print("")

# The full lensing likelihood:
CMBlkl_lensing = clik.clik_lensing(PLANCK_PATH +'/baseline/plc_3.0/lensing/smicadx12_Dec5_ftl_mv2_ndclpp_p_teb_consext8.clik_lensing')
# print("CMBlkl_lensing")
# print(CMBlkl_lensing.get_extra_parameter_names())
# print(CMBlkl_lensing.get_lmax())
# #print(CMBlkl_lensing.get_clcmb_fid())
# print("---------------------")
# print("")
# print("")

# Here we fix the Planck nuisance parameters to base_plikHM_TTTEEE_lowl_lowE_lensing
A_cib_217 = 0.4605402E+02
cib_index = -0.1300000E+01
xi_sz_cib = 0.6567009E+00
A_sz = 0.7083803E+01

ps_A_100_100 = 0.2482123E+03
ps_A_143_143 = 0.5067985E+02 
ps_A_143_217 = 0.5330959E+02
ps_A_217_217 = 0.1218608E+03 

ksz_norm = 0.3846930E-02
gal545_A_100 = 0.8802494E+01
gal545_A_143 = 0.1100657E+02
gal545_A_143_217 = 0.2015894E+02  
gal545_A_217 = 0.9545041E+02 

galf_EE_A_100 = 0.055
galf_EE_A_100_143 = 0.040
galf_EE_A_100_217 = 0.094
galf_EE_A_143 = 0.086
galf_EE_A_143_217 = 0.21
galf_EE_A_217 = 0.70
galf_EE_index = -2.4

galf_TE_A_100 = 0.1138247E+00
galf_TE_A_100_143 = 0.1345639E+00 
galf_TE_A_100_217 = 0.4787342E+00 
galf_TE_A_143 = 0.2248485E+00
galf_TE_A_143_217 = 0.6649451E+00
galf_TE_A_217 = 0.2082494E+01 
galf_TE_index = -2.4

A_cnoise_e2e_100_100_EE = 1
A_cnoise_e2e_143_143_EE = 1
A_cnoise_e2e_217_217_EE = 1

A_sbpx_100_100_TT = 1
A_sbpx_143_143_TT = 1
A_sbpx_143_217_TT = 1
A_sbpx_217_217_TT = 1

A_sbpx_100_100_EE = 1
A_sbpx_100_143_EE = 1
A_sbpx_100_217_EE = 1
A_sbpx_143_143_EE = 1
A_sbpx_143_217_EE = 1
A_sbpx_217_217_EE = 1

calib_100T = 0.9997421E+00
calib_217T = 0.9981871E+00
calib_100P = 0.1021000E+01
calib_143P = 0.9660000E+00
calib_217P = 0.1040000E+01

A_pol = 1
A_planck = 0.1000442E+01 

# Here we make a vector for the nuisance parameters 
nuisance = [A_cib_217, cib_index, xi_sz_cib, A_sz, ps_A_100_100, ps_A_143_143, ps_A_143_217, ps_A_217_217, ksz_norm, gal545_A_100, gal545_A_143, gal545_A_143_217, gal545_A_217, galf_EE_A_100, galf_EE_A_100_143, galf_EE_A_100_217, galf_EE_A_143, galf_EE_A_143_217, galf_EE_A_217, galf_EE_index, galf_TE_A_100, galf_TE_A_100_143, galf_TE_A_100_217, galf_TE_A_143, galf_TE_A_143_217, galf_TE_A_217, galf_TE_index, A_cnoise_e2e_100_100_EE, A_cnoise_e2e_143_143_EE, A_cnoise_e2e_217_217_EE, A_sbpx_100_100_TT, A_sbpx_143_143_TT, A_sbpx_143_217_TT, A_sbpx_217_217_TT, A_sbpx_100_100_EE, A_sbpx_100_143_EE, A_sbpx_100_217_EE, A_sbpx_143_143_EE, A_sbpx_143_217_EE, A_sbpx_217_217_EE, calib_100T, calib_217T, calib_100P, calib_143P, calib_217P, A_pol, A_planck]