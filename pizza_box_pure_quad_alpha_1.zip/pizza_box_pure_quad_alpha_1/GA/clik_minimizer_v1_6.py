from __future__ import division
#from sympy import *
from sympy.printing.c import C99CodePrinter
import sympy as sym
import numpy as np
import math
from scipy.optimize import fmin

import sys
sys.path.append('/home/iftuser/planck/GATO/')

import ga_clik_inflation_v1 as gac

def V_staro(phi,V0,phi0):
    gamma_S = math.sqrt(2./3.)*math.sqrt(8.*math.pi)
    return V0*pow(1.-sym.exp(gamma_S*(phi-phi0)),2.)

def chi2f(y):
    #Vphi = y[0]+0.5*pow(y[1],2.)*pow(phi-y[2],2.)
    Vphi = 0.5*pow(y[0],2.)*pow(phi-y[1],2.)
	# The derivatives
    dVGA=sym.diff(Vphi,phi)
    ddVGA=sym.diff(dVGA,phi)
    # Convert to strings
    VGAs=str(printer.doprint(Vphi))
    dVGAs=str(printer.doprint(dVGA))
    ddVGAs=str(printer.doprint(ddVGA))
    return gac.chi2_CMB_potential(VGAs,dVGAs,ddVGAs)

# Here define a potential in terms of phi in python notation
phi=sym.symbols("phi")
printer = C99CodePrinter()

y_0 = 1.171e-6
y_1 = 3.1
# y_0 = 1.161e-12
# y_1 = 1.43675e-6
# y_2 = 2.455
print(chi2f([y_0,y_1]))
#exit()

print("")
print("------------------------------")
print("")
print('Now running minimization...')
minimum=fmin(chi2f,[y_0,y_1])
print(minimum)
print(chi2f(minimum))

print("")
print("------------------------------")
print("")
print('chi^2 from P(k)~As k^(ns-1)...')
gac.chi2_CMB_analytic()

print("")
print("------------------------------")
print("")
chi2exp = [23.25147965785152, 396.049933292438, 2344.9308271318932, 8.867964585046845]
print("Best-fit Planck chi^2:")
print(chi2exp)
print(sum(chi2exp))

exit()